# CV MÉTIER — Prototype fonctionnel

Premier générateur de CV français spécialisé dans le métier de **préparateur / préparatrice de commandes**.

## Essayer

Ouvrir `index.html` dans un navigateur moderne (ou servir le dossier par un serveur statique). Le formulaire fonctionne **sans installation, sans compte, sans API et sans connexion**.

## Fonctionnalités

- Formulaire guidé en quatre étapes : profil, parcours, compétences, modèle.
- Profil débutant ou expérimenté ; suggestion de résumé modifiable, sans IA ni inventions de compétences.
- Mise à jour instantanée de l'aperçu.
- Trois styles professionnels.
- Export en PDF via le système d'impression intégré au navigateur : sélectionner « Enregistrer au format PDF ». Le fichier contient un CV A4 imprimable.
- Données du candidat conservées seulement dans l'onglet ouvert : aucune transmission, aucune base de données, aucun traqueur ni analytics. Une actualisation de la page efface les champs non sauvegardés.
- Version responsive : ordinateur et téléphone.
- Site statique compatible avec Cloudflare Pages, GitHub Pages et tout hébergeur web statique.

## Déployer sans toucher à VORTEX PICKS

Créer un **nouveau** dépôt et un **nouveau** projet Cloudflare Pages, puis y importer les fichiers du dossier `cv-metier`. Ne pas réutiliser le dépôt ou le Worker existant de VORTEX PICKS. En déploiement direct, téléverser le dossier sur Pages ; en Git, configurer le dossier de sortie sur `/` sans commande de build.

## Limites et prochaines étapes

- **Aucun paiement n'est activé.** Le téléchargement est gratuit dans ce prototype, pour tester l'usage avant d'intégrer un véritable paiement sécurisé.
- La prévisualisation n'est pas une validation de compétences : le candidat doit vérifier chaque affirmation avant d'envoyer son CV.
- Suggestions de phrases génériques ; pas de génération automatisée de lettres de motivation pour le moment.
- La sortie PDF repose sur le moteur d'impression du navigateur. Les utilisateurs peuvent ajuster les marges et désactiver en-têtes/pieds de page.
- Pour un lancement commercial : identité du vendeur, CGV, mentions légales, politique de confidentialité, accès aux services concernés, consentement éventuel aux cookies, éventuels remboursements, solution de paiement (Stripe Checkout par exemple), mise en conformité et prévention des abus.
- Recherche de marché : vérifier les mots-clés par métier et les intentions de paiement avant de déployer de la publicité. La visibilité SEO n'est pas garantie.

## Structure

- `index.html` : page publique et formulaire
- `styles.css` : responsive + impression A4
- `app.js` : données en local, formulaires, aperçu, export

Licence : code de démonstration fourni pour le projet de l'utilisateur.
